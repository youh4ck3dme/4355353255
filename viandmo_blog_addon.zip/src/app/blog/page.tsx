import { allPosts } from 'contentlayer/generated'
import PostCard from './(components)/PostCard'
import Filters from './(components)/Filters'

function matches(post: any, q: string | null, tag: string | null, cat: string | null, year: string | null){
  const hay = `${post.title} ${post.excerpt ?? ''} ${post.category} ${(post.tags ?? []).join(' ')}`.toLowerCase()
  const okQ = q ? hay.includes(q.toLowerCase()) : true
  const okTag = tag ? (post.tags ?? []).map((t:string)=>t.toLowerCase()).includes(tag.toLowerCase()) : true
  const okCat = cat ? post.category?.toLowerCase() === cat.toLowerCase() : true
  const okYear = year ? String(new Date(post.date).getFullYear()) === String(year) : true
  return okQ && okTag && okCat && okYear
}

export const metadata = {
  title: 'Blog o sťahovaní | VI&MO',
  description: 'Tipy, archív, vyhľadávanie a lokálne rady pre sťahovanie v Bratislave.'
}

export default function BlogPage({ searchParams }: { searchParams: Record<string,string|undefined> }){
  const q = searchParams.q ?? null
  const tag = searchParams.tag ?? null
  const cat = searchParams.cat ?? null
  const year = searchParams.year ?? null

  const posts = allPosts
    .filter((p)=>!p.draft)
    .sort((a,b)=> +new Date(b.date) - +new Date(a.date))
    .filter(p => matches(p, q, tag, cat, year))

  const tags = Array.from(new Set(allPosts.flatMap(p => p.tags ?? [])))
  const cats = Array.from(new Set(allPosts.map(p => p.category)))

  return (
    <main className="mx-auto max-w-4xl p-6 space-y-6">
      <header>
        <h1 className="text-3xl font-semibold">Blog</h1>
        <p className="opacity-80">Archív, filtre a fulltext pre články o sťahovaní.</p>
      </header>

      <Filters allTags={tags} allCategories={cats} />

      <section className="mt-6 grid gap-4">
        {posts.map((p)=> <PostCard key={p.slug} post={p as any} />)}
        {!posts.length && <p>Žiadne články nespĺňajú filter.</p>}
      </section>
    </main>
  )
}
