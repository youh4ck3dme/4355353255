'use client'
import { usePathname, useRouter, useSearchParams } from 'next/navigation'
import { useState, useEffect } from 'react'

export default function BlogFilters({ allTags, allCategories }:{ allTags:string[], allCategories:string[] }){
  const sp = useSearchParams()
  const router = useRouter()
  const pathname = usePathname()
  const [q, setQ] = useState(sp.get('q') ?? '')
  const [tag, setTag] = useState(sp.get('tag') ?? '')
  const [cat, setCat] = useState(sp.get('cat') ?? '')
  const [year, setYear] = useState(sp.get('year') ?? '')

  useEffect(()=>{
    setQ(sp.get('q') ?? '')
    setTag(sp.get('tag') ?? '')
    setCat(sp.get('cat') ?? '')
    setYear(sp.get('year') ?? '')
  }, [sp])

  const apply = () => {
    const p = new URLSearchParams()
    if (q) p.set('q', q)
    if (tag) p.set('tag', tag)
    if (cat) p.set('cat', cat)
    if (year) p.set('year', year)
    router.push(`${pathname}?${p.toString()}`)
  }

  return (
    <div className="grid gap-2 sm:grid-cols-4">
      <input value={q} onChange={(e)=>setQ(e.target.value)} placeholder="Hľadať…" className="rounded border p-2" />
      <select value={tag} onChange={(e)=>setTag(e.target.value)} className="rounded border p-2">
        <option value="">Tag</option>
        {allTags.map(t => <option key={t} value={t}>{t}</option>)}
      </select>
      <select value={cat} onChange={(e)=>setCat(e.target.value)} className="rounded border p-2">
        <option value="">Kategória</option>
        {allCategories.map(c => <option key={c} value={c}>{c}</option>)}
      </select>
      <input value={year} onChange={(e)=>setYear(e.target.value)} placeholder="Rok (YYYY)" className="rounded border p-2" />
      <button onClick={apply} className="mt-2 rounded-md border px-3 py-2 sm:col-span-4">Filtrovať</button>
    </div>
  )
}
