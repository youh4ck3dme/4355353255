'use client'

import { InstantSearchNext } from 'react-instantsearch-nextjs'
import { SearchBox, Hits, RefinementList, Pagination } from 'react-instantsearch'
import Link from 'next/link'

function Hit({ hit }: any){
  return <div className="p-2 border rounded">
    <Link href={`/blog/${hit.slug}`}>{hit.title}</Link>
    {hit.excerpt && <p className="opacity-80 text-sm">{hit.excerpt}</p>}
  </div>
}

export default function AlgoliaSearch({ searchClient, indexName }:{ searchClient:any, indexName:string }){
  return (
    <InstantSearchNext searchClient={searchClient} indexName={indexName}>
      <div className="grid gap-3">
        <SearchBox placeholder="Hľadať v blogu…" />
        <RefinementList attribute="category" />
        <RefinementList attribute="tags" />
        <Hits hitComponent={Hit} />
        <Pagination />
      </div>
    </InstantSearchNext>
  )
}
