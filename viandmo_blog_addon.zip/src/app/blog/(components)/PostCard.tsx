import Link from 'next/link'
import type { Post } from 'contentlayer/generated'

export default function PostCard({ post }: { post: Post }) {
  return (
    <article className="rounded-xl border p-4">
      <h3 className="text-xl font-semibold">
        <Link href={post.url}>{post.title}</Link>
      </h3>
      <p className="text-sm text-gray-600">{new Date(post.date).toLocaleDateString('sk-SK')}</p>
      {post.excerpt && <p className="mt-2">{post.excerpt}</p>}
      <div className="mt-2 text-sm">
        <span className="opacity-70">#{post.category}</span>
        {post.tags?.length ? (
          <span className="opacity-70"> · {post.tags.map(t => `#${t}`).join(' ')}</span>
        ) : null}
      </div>
    </article>
  )
}
