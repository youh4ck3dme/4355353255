'use client'

import { InstantSearch } from 'react-instantsearch'
import { SearchBox, Hits, RefinementList, Pagination } from 'react-instantsearch'
import TypesenseInstantSearchAdapter from 'typesense-instantsearch-adapter'
import Link from 'next/link'

function Hit({ hit }: any){
  return <div className="p-2 border rounded">
    <Link href={`/blog/${hit.slug}`}>{hit.title}</Link>
    {hit.excerpt && <p className="opacity-80 text-sm">{hit.excerpt}</p>}
  </div>
}

export default function TypesenseSearch({ host, apiKey, indexName }:{ host:string, apiKey:string, indexName:string }){
  const adapter = new TypesenseInstantSearchAdapter({
    server: { apiKey, nodes: [{ host, port: 443, protocol: 'https' }], cacheSearchResultsForSeconds: 3 },
    additionalSearchParameters: { query_by: 'title,excerpt,tags,category' }
  })

  return (
    <InstantSearch searchClient={adapter.searchClient} indexName={indexName}>
      <div className="grid gap-3">
        <SearchBox placeholder="Hľadať v blogu…" />
        <RefinementList attribute="category" />
        <RefinementList attribute="tags" />
        <Hits hitComponent={Hit} />
        <Pagination />
      </div>
    </InstantSearch>
  )
}
