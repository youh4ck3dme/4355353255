import { allPosts } from 'contentlayer/generated'
import Link from 'next/link'

export const metadata = {
  title: 'Archív článkov | VI&MO',
  description: 'Prehľad článkov podľa roku a mesiaca.'
}

export default function ArchivePage({ params }:{ params: { year?: string, month?: string } }){
  const year = (params as any).year
  const month = (params as any).month
  const posts = allPosts.filter(p => {
    const y = String(new Date(p.date).getFullYear())
    const m = String(new Date(p.date).getMonth()+1).padStart(2,'0')
    return (!year || y===year) && (!month || m===month)
  }).sort((a,b)=> +new Date(b.date) - +new Date(a.date))

  const grouped = new Map<string, any[]>()
  posts.forEach(p => {
    const y = String(new Date(p.date).getFullYear())
    const m = String(new Date(p.date).getMonth()+1).padStart(2,'0')
    const key = `${y}-${m}`
    if(!grouped.has(key)) grouped.set(key, [])
    grouped.get(key)!.push(p)
  })

  return (
    <main className="mx-auto max-w-4xl p-6 space-y-6">
      <h1 className="text-3xl font-semibold">Archív</h1>
      {[...grouped.entries()].map(([ym, list]) => (
        <section key={ym}>
          <h2 className="text-xl font-semibold">{ym}</h2>
          <ul className="list-disc pl-6">
            {list.map(p => <li key={p.slug}><Link href={p.url}>{p.title}</Link></li>)}
          </ul>
        </section>
      ))}
      {!posts.length && <p>Žiadne články pre daný filter.</p>}
    </main>
  )
}
