import { allPosts } from 'contentlayer/generated'
import { notFound } from 'next/navigation'
import { format } from 'date-fns'
import sk from 'date-fns/locale/sk'
import { blogPostingJsonLd, breadcrumbJsonLd } from '@/src/lib/jsonld-article'

export async function generateStaticParams(){
  return allPosts.map(p => ({ slug: p.slug }))
}

export async function generateMetadata({ params }:{ params: { slug:string } }){
  const post = allPosts.find(p => p.slug === params.slug)
  if(!post) return {}
  return {
    title: `${post.title} | VI&MO`,
    description: post.excerpt ?? '',
    alternates: { canonical: `/blog/${post.slug}` }
  }
}

export default function PostPage({ params }:{ params: { slug:string } }){
  const post = allPosts.find(p => p.slug === params.slug)
  if(!post) return notFound()

  const jsonLd = blogPostingJsonLd({
    headline: post.title,
    description: post.excerpt ?? '',
    datePublished: post.date,
    dateModified: post.updated ?? post.date,
    url: `https://app.viandmo.com${post.url}`,
    image: post.cover ?? undefined,
    authorName: post.author ?? 'VI&MO tím'
  })

  const crumbs = breadcrumbJsonLd([
    { name: 'Domov', url: 'https://app.viandmo.com/' },
    { name: 'Blog', url: 'https://app.viandmo.com/blog' },
    { name: post.title, url: `https://app.viandmo.com${post.url}` }
  ])

  return (
    <main className="mx-auto max-w-3xl p-6 prose prose-slate">
      <h1>{post.title}</h1>
      <p className="opacity-70 text-sm">{format(new Date(post.date), 'd. MMMM yyyy', { locale: sk })}</p>

      {/* MDX body */}
      <article dangerouslySetInnerHTML={{ __html: post.body.html }} />

      {/* JSON-LD */}
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(crumbs) }} />

      {/* giscus comments (replace data-repo etc.) */}
      <section className="mt-10">
        <script src="https://giscus.app/client.js"
          data-repo="OWNER/REPO"
          data-repo-id="REPO_ID"
          data-category="General"
          data-category-id="CATEGORY_ID"
          data-mapping="pathname"
          data-strict="1"
          data-reactions-enabled="1"
          data-emit-metadata="0"
          data-input-position="bottom"
          data-theme="light"
          data-lang="sk"
          crossOrigin="anonymous"
          async>
        </script>
        <noscript>Na zobrazenie komentárov povoľte JavaScript.</noscript>
      </section>
    </main>
  )
}
