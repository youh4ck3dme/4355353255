import { allPosts } from 'contentlayer/generated'

export const dynamic = 'force-static'

export async function GET() {
  const items = allPosts
    .filter(p=>!p.draft)
    .sort((a,b)=> +new Date(b.date) - +new Date(a.date))
    .slice(0, 50)
    .map(p => `
      <item>
        <title><![CDATA[${p.title}]]></title>
        <link>https://app.viandmo.com${p.url}</link>
        <guid>https://app.viandmo.com${p.url}</guid>
        <pubDate>${new Date(p.date).toUTCString()}</pubDate>
        ${p.excerpt ? `<description><![CDATA[${p.excerpt}]]></description>` : ''}
      </item>
    `).join('\n')

  const xml = `<?xml version="1.0" encoding="UTF-8" ?>
  <rss version="2.0">
    <channel>
      <title>VI&MO – Blog</title>
      <link>https://app.viandmo.com/blog</link>
      <description>Novinky a tipy k sťahovaniu v Bratislave</description>
      ${items}
    </channel>
  </rss>`

  return new Response(xml, { headers: { 'Content-Type': 'application/rss+xml; charset=utf-8', 'Cache-Control': 's-maxage=3600, stale-while-revalidate=86400' } })
}
