type BlogPostingArgs = {
  headline: string
  description?: string
  url: string
  datePublished: string
  dateModified?: string
  image?: string
  authorName?: string
}

export function blogPostingJsonLd(args: BlogPostingArgs){
  return {
    '@context': 'https://schema.org',
    '@type': 'BlogPosting',
    headline: args.headline,
    description: args.description,
    url: args.url,
    datePublished: args.datePublished,
    dateModified: args.dateModified ?? args.datePublished,
    image: args.image,
    author: args.authorName ? { '@type': 'Person', name: args.authorName } : undefined,
    publisher: { '@type': 'Organization', name: 'VI&MO' }
  }
}

export function breadcrumbJsonLd(items: { name: string, url: string }[]){
  return {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: items.map((it, idx) => ({
      '@type': 'ListItem',
      position: idx + 1,
      name: it.name,
      item: it.url
    }))
  }
}
