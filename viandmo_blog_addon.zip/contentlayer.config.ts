import { defineDocumentType, makeSource } from 'contentlayer/source-files'
import rehypeSlug from 'rehype-slug'
import rehypeAutolinkHeadings from 'rehype-autolink-headings'
import remarkGfm from 'remark-gfm'

export const Post = defineDocumentType(() => ({
  name: 'Post',
  filePathPattern: `**/*.mdx`,
  contentType: 'mdx',
  fields: {
    title: { type: 'string', required: true },
    slug: { type: 'string', required: true },
    excerpt: { type: 'string', required: false },
    date: { type: 'date', required: true },
    updated: { type: 'date', required: false },
    category: { type: 'string', required: true },
    tags: { type: 'list', of: { type: 'string' }, required: false },
    cover: { type: 'string', required: false },
    author: { type: 'string', required: false },
    draft: { type: 'boolean', required: false, default: false }
  },
  computedFields: {
    url: { type: 'string', resolve: (post) => `/blog/${post.slug}` },
    year: { type: 'string', resolve: (post) => String(new Date(post.date).getFullYear()) },
    month: { type: 'string', resolve: (post) => String(new Date(post.date).getMonth() + 1).padStart(2,'0') }
  }
}))

export default makeSource({
  contentDirPath: 'src/content/blog',
  documentTypes: [Post],
  mdx: { 
    remarkPlugins: [remarkGfm],
    rehypePlugins: [rehypeSlug, [rehypeAutolinkHeadings, { behavior: 'wrap' }]]
  }
})
