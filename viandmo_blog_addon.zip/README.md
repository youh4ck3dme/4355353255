# VI&MO – Blog Add-on (App Router + Contentlayer + RSS + Search)
Generated: 2025-10-19T17:02:26.490345Z


## Čo je v balíku
- Contentlayer MDX blog (`src/content/blog/*.mdx`), kategórie/tagy/archív (rok/mesiac)
- Blog list (`/blog`) s filtrami a jednoduchým fulltextom na strane klienta
- Detail článku (`/blog/[slug]`) s JSON-LD (BlogPosting + BreadcrumbList) a giscus komentármi
- Archív (`/blog/archiv/[year]/[month]`)
- RSS feed cez Route Handler (`/feed.xml`)
- Pripravené komponenty pre vyhľadávanie:
  - **Algolia (SaaS)** – `AlgoliaSearch.tsx` (React InstantSearch Next v7)
  - **Typesense (OSS)** – `TypesenseSearch.tsx` (typesense-instantsearch-adapter)
- Pomocné JSON-LD funkcie: `src/lib/jsonld-article.ts`

## Inštalácia
1. Balíky:
   ```bash
   pnpm add contentlayer next-contentlayer remark-gfm rehype-slug rehype-autolink-headings date-fns
   # vyhľadávanie (vyber si jedno):
   pnpm add react-instantsearch-nextjs  # Algolia
   # alebo:
   pnpm add typesense-instantsearch-adapter react-instantsearch  # Typesense
   ```
2. `next.config.js`:
   ```js
   const { withContentlayer } = require('next-contentlayer')
   module.exports = withContentlayer({})
   ```
3. Spusti dev/build pre generovanie `contentlayer/generated`.
4. **giscus**: na https://giscus.app/ vytvor snippet a nahraď `data-repo*` hodnoty v `src/app/blog/[slug]/page.tsx`.
5. Pridaj `<link rel="alternate" type="application/rss+xml" href="/feed.xml" />` do layoutu.

## Tipy
- Index pre vyhľadávanie: `slug`, `title`, `excerpt`, `category`, `tags[]`, `date`.
- Pre archív môžeš doplniť prehľad: `/blog/archiv/2025/10`.
- Udržuj `dateModified` pri editácii, pre lepšie výsledky vo vyhľadávaní.
